<script type="text/javascript">
      $(document).ready(function() {
        $("#lightSlider").lightSlider({
        item: 1,
        autoWidth: false   
	    });
      });
    </script>

</body>
</html>